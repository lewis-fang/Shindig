#include"CNNLayer.h"

CNNCalc::CNNCalc()
{
	isSetData = false;
	isSetConfig = false;
	activateType = 2;
	poolingFun = 0;
	poolingRow = 2;
	poolingCol = 2;
	poolingStride = 2;
	HideLayerNumth = 0;
	paddingrow = 0;
	paddingcol = 0;
	padMoethod = SAME;
	thisLayerType = CONVOLUTION;
	isBufferInitiated = false;
	
}
void CNNCalc::SetActivateFun(int Act)
{
	activateType = Act;
}
void CNNCalc::SetInput(image imago)
{
	

	inputImage.imageData = new double**[imago.channel];
	for (int ch = 0; ch < imago.channel; ch++)
	{
		inputImage.imageData[ch] = new double*[imago.rows];
		for (int r = 0; r <imago.rows; r++)
		{
			inputImage.imageData[ch][r] = new double[imago.cols];
		}
	}
	//memset(originalImage, 0.0, channel*row*col);

	for (int ch = 0; ch < imago.channel; ch++)
	{
		for (int r = 0; r < imago.rows; r++)
		{
			for (int c = 0; c < imago.cols; c++)
			{
				inputImage.imageData[ch][r][c] = imago.imageData[ch][r][c];
			}
		}
	}
	inputImage.rows = imago.rows;;//H
	inputImage.cols = imago.cols;;//W
	inputImage.channel = imago.channel;
	isSetData = true;
}
bool CNNCalc::SetKernals(std::vector<kernal> kernals, int kernalrow, int kernalcol, int padsz, int strd, int ns)
{
	paddingrow = padsz;
	paddingcol = padsz;
	stride = strd;
	kernalRows = kernalrow;
	kernalCols = kernalcol;
	kernalChannel = 1;
	neuroNums = ns;

	CNNKernals = new kernal[neuroNums];
	if (kernals.size() == ns)
	{
		for (int kn = 0; kn < neuroNums; kn++)
		{
			CNNKernals[kn].row = kernalRows;
			CNNKernals[kn].col = kernalCols;
			CNNKernals[kn].channel = kernalChannel;
			CNNKernals[kn].initKernal(1);
			for (int ch = 0; ch < kernalChannel; ch++)
			{
				for (int r = 0; r < kernalrow; r++)
				{
					for (int c = 0; c < kernalcol; c++)
					{
						CNNKernals[kn].weight[ch][r][c] = kernals.at(kn).weight[ch][r][c];
					}
				}
			}
		}

		isSetConfig = true;
		return true;
	}
	else
	{
		return false;
	}

}
void CNNCalc::SetPoolings(int pldim1, int pldim2, int plStrd,int plFun)
{
	poolingRow = pldim1;
	poolingCol = pldim2;
	poolingStride = plStrd;
	poolingFun = plFun;
}

bool CNNCalc::LaunchConvolution()
{
	if (isSetData & isSetConfig)
	{
		if (!isBufferInitiated)
		{
			initLayerMemory(inputImage.rows, inputImage.cols, inputImage.channel);

		}
		std::cout << "start layer convolution:" << HideLayerNumth << std::endl;
		padding();
		std::cout << "padding is finished,padding size is:" << paddingrow<< std::endl;
		Convolution();	
		std::cout << "convolution is finished,~" << std::endl;
		if (thisLayerType == CONVOLUTION)
		{
			pooling();
			std::cout << "pooling is finished~" << std::endl;
		}		
		return true;
	}
	else
	{
		std::cout << "I'm not read:" << isSetData <<","<< isSetConfig<<std::endl;
		return false;
	}
}
void CNNCalc::ReOrder(){}
void CNNCalc::Convolution()
{
	
	for (int kn = 0; kn < neuroNums; kn++)
	{	
		kernal CurrentKernal = CNNKernals[kn];
		int OutBuffer1IndexX = 0;
		for (int r = 0; r < padImage.rows - kernalRows+1; r+=stride)
		{
			int OutBuffer1IndexY = 0;
			for (int c = 0; c < padImage.cols - kernalCols + 1; c += stride)
			{
				double currentValue = 0.0;
				for (int kr = 0; kr < kernalRows; kr++)
				{
					for (int kc = 0; kc < kernalCols; kc++)
					{
						for (int kch = 0; kch < kernalChannel; kch++)
						{
							currentValue += CurrentKernal.weight[kch][kr][kc] * padImage.imageData[kch][r + kr][c + kc];
						}
					}
				}

				actImage.imageData[kn][OutBuffer1IndexX][OutBuffer1IndexY] = activate(currentValue, 2);
				OutBuffer1IndexY++;
					
			}
			OutBuffer1IndexX++;
		}
		
	}

}
void CNNCalc::setOutBuffer()
{
	actImage.rows = (padImage.rows - kernalRows) / stride + 1;
	actImage.cols = (padImage.cols - kernalCols) / stride + 1;
	actImage.channel = neuroNums;
	actImage.imageData = new double**[actImage.channel];
	for (int kn = 0; kn < actImage.channel; kn++)
	{
		actImage.imageData[kn] = new double*[actImage.rows];
		for (int r = 0; r < actImage.rows; r++)
		{
			actImage.imageData[kn][r] = new double[actImage.cols];
		}
	}	//memset(outputBuffer1, 0, OutBuffer1Dim1*OutBuffer1Dim2*OutBuffer1Dim3);
}
void CNNCalc::padding()
{

	for (int ch = 0; ch < padImage.channel; ch++)
	{
		for (int r = 0; r < padImage.rows; r++)
		{
			for (int c = 0; c < padImage.cols; c++)
			{
				if (r<paddingrow | r> inputImage.rows + paddingrow - 1 | c<paddingcol | c> inputImage.cols + paddingcol - 1)
				{
					padImage.imageData[ch][r][c] = 0;
				}
				else
				{
					padImage.imageData[ch][r][c] = inputImage.imageData[ch][r - paddingrow][c - paddingcol];
				}
				
			}
		}
	}
}
void CNNCalc::pooling()
{
	
	for (int kn = 0; kn < actImage.channel; kn++)
	{

		int outBuffer2IndexX = 0;
		for (int r = 0; r < actImage.rows - poolingRow + 1; r += poolingStride)
		{
			int outBuffer2IndexY = 0;
			for (int c = 0; c < actImage.cols - poolingCol + 1; c += poolingStride)
			{
				double currentValue = 0.0;
				for (int i = 0; i < poolingRow; i++)
				{
					for (int j = 0; j < poolingCol; j++)
					{
						if (poolingFun == 0)
						{
							if (actImage.imageData[kn][r + i][c + j]>currentValue)
							{
								currentValue = actImage.imageData[kn][r + i][c + j];
							}
						}
						else
						{
							currentValue += actImage.imageData[kn][r + i][c + j] / (poolingRow*poolingCol);
						}
					}
				}
				outImage.imageData[kn][outBuffer2IndexX][outBuffer2IndexY] = currentValue;
				outBuffer2IndexY++;
			}
			outBuffer2IndexX++;
		}
	}
}
double CNNCalc::activate(double a, int fun)
{
	if (fun == 2)
	{//Relu
		if (a < 0)
		{
			return 0;
		}
		else
		{
			return a;
		}
	}
	else
	{
		if (a < 0)
		{
			return 0;
		}
		else
		{
			return a;
		}
	}
}
void CNNCalc::setOutBuffer2()
{
	outImage.channel = neuroNums;
	outImage.rows = (actImage.rows - poolingRow) / poolingStride + 1;
	outImage.cols = (actImage.cols - poolingCol) / poolingStride + 1;;
	outImage.imageData = new double**[outImage.channel];
	outImage.imageData = new double**[outImage.channel];
	for (int kn = 0; kn < outImage.channel; kn++)
	{
		outImage.imageData[kn] = new double*[outImage.rows];
		for (int r = 0; r < outImage.rows; r++)
		{
			outImage.imageData[kn][r] = new double[outImage.cols];
		}
	}	//memset(outputBuffer2, 0, OutBuffer2Dim1*OutBuffer2Dim2*OutBuffer2Dim3);
}

void CNNCalc::initKernals(int wtsRow, int wtsCol, int wtsChannel, int ns,int strd)
{

	stride = strd;
	kernalRows = wtsRow;
	kernalCols = wtsCol;
	kernalChannel = wtsChannel;
	neuroNums = ns;

	CNNKernals = new kernal[neuroNums];
	BL.shadowKernals = new kernal[neuroNums];
	for (int kn = 0; kn < neuroNums; kn++)
	{
		CNNKernals[kn].row = kernalRows;
		CNNKernals[kn].col = kernalCols;
		CNNKernals[kn].channel = kernalChannel;
		CNNKernals[kn].initKernal(1);

		BL.shadowKernals[kn].row = kernalRows;
		BL.shadowKernals[kn].col = kernalCols;
		BL.shadowKernals[kn].channel = kernalChannel;
		BL.shadowKernals[kn].initKernal(0);
	}

	isSetConfig = true;
	
}
void CNNCalc::initLayerMemory(int inRows, int inCols, int inChannel)
{

	inputImage.channel = inChannel;
	inputImage.rows = inRows;
	inputImage.cols = inCols;
	if (padMoethod == SMALLER | thisLayerType == FULLYCONNECTION)
	{
		paddingrow = 0;
		paddingcol = 0;
	}
	else
	{
		paddingrow = kernalRows;
		paddingcol = kernalCols / 2;
	}
	padImage.channel = inputImage.channel;
	padImage.rows = inputImage.rows + 2 * paddingrow;
	padImage.cols = inputImage.cols + 2 * paddingcol;
	padImage.imageData = new double**[padImage.channel];
	for (int ch = 0; ch < padImage.channel; ch++)
	{
		padImage.imageData[ch] = new double*[padImage.rows];
		for (int r = 0; r < padImage.rows; r++)
		{
			padImage.imageData[ch][r] = new double[padImage.cols];
		}
	}
	std::cout << "padding image is initialized~" << std::endl;
	setOutBuffer();
	std::cout << "activated image is initialized~" << std::endl;
	setOutBuffer2();
	std::cout << "Out image is initialized~" << std::endl;
	std::cout << inputImage.rows << ",abd," << inputImage.cols << std::endl;
	std::cout << padImage.rows << ",abd," << padImage.cols << std::endl;
	//std::cout << padImage.rows << ",abd," << padImage.cols << std::endl;
	std::cout << actImage.rows << ",abd," << actImage.cols << std::endl;
	std::cout << outImage.rows << ",abd," << outImage.cols << std::endl;
	isBufferInitiated = true;
}
const image CNNCalc::getOutImage()
{
	if (thisLayerType == CONVOLUTION)
	{
		return outImage;
	}
	else
	{
		return actImage;
	}
	
}
bool CNNCalc::UpdateLayerLoss(image& retImage)
{//update dC/dI
	bool ret = true;
	image dCVsdI;;
	if (thisLayerType == layerType::CONVOLUTION)
	{
		image dpoolingIMG;
		ret = BL.dPooling(actImage, BL.dIdealOutVSdO, dpoolingIMG);
		//dc/dA=dC/dOut(.)dOut/dA
		if (ret)
		{
			kernal* kernalSeries180 = BL.TMatrixKernal(CNNKernals, neuroNums);
			ret = BL.dConvolutionX(inputImage, dpoolingIMG, kernalSeries180, neuroNums, retImage);
		}
	}
	else if (thisLayerType == layerType::FULLYCONNECTION)
	{
		kernal* kernalSeries180 = BL.TMatrixKernal(CNNKernals, neuroNums);
		ret = BL.dConvolutionX(inputImage, BL.dIdealOutVSdO, kernalSeries180, neuroNums, retImage);
	}
	else
	{
		ret = false;
	}

	return ret;

}
bool CNNCalc::setOutLossss(image umg)
{
	/*
	if (sz != neuroNums)
	{
		return false;
	}
	if (BL.Loss == NULL)
	{
		BL.Loss = new double[sz];
		memset(BL.Loss, 0.0, sz);
	}
	for (int i = 0; i < sz; i++)
	{
		BL.Loss[i] = lossSeries[i];
	}
	*/
	BL.dIdealOutVSdO = umg;
	return true;
}
void CNNCalc::UpdateLayerWB(int bs)
{//update weights
	bool ret = true;
	kernal* dkernal;
	if (thisLayerType == layerType::CONVOLUTION)
	{
		image dpoolingIMG;
		ret = BL.dPooling(actImage, BL.dIdealOutVSdO, dpoolingIMG);
		//dc/dA=dC/dOut(.)dOut/dA
		if (ret)
		{		
			ret=BL.dConvolutionW(inputImage, dpoolingIMG, dkernal, neuroNums);
		}
	}
	else if (thisLayerType == layerType::FULLYCONNECTION)
	{
		ret = BL.dConvolutionW(inputImage, BL.dIdealOutVSdO, dkernal, neuroNums);
	}
	else
	{
		ret = false;
	}
	if (ret)
	{
		for (int kn = 0; kn < neuroNums; kn++)
		{
			dkernal[kn].apply(-BL.learnRate/bs);
			BL.shadowKernals[kn] += dkernal[kn];
		}
	}
}
bool CNNCalc::BackLayer::dConvolutionX(image inPa, image outZ, kernal* K180, int Kn, image& dImage)
{//(4) 
	dImage.channel = inPa.channel;
	dImage.cols = inPa.cols;
	dImage.rows = inPa.rows;
	dImage.initImage();
	int kernalcol = K180[0].col;
	int kernalrow = K180[0].row;
	if (outZ.channel != Kn)
	{
		return false;
	}
	image dPaddingImage;
	if (stride > 1)
	{
		innerPadding(outZ, dPaddingImage,stride-1,stride-1);
	}
	else
	{
		dPaddingImage = outZ;
	}

	int ConvolutionX = 0;
	int ConvolutionY = 0;
	for (int ch = 0; ch < dImage.channel; ch++)
	{
		for (int r = 0; r < dPaddingImage.rows; r += 1)
		{
			for (int c = 0; c < dPaddingImage.cols; c += 1)
			{
				double currentValue = 0.0;
				for (int k = 0; k < Kn; k++)
				{
					for (int kr = 0; kr < kernalrow; kr++)
					{
						for (int kc = 0; kc < kernalcol; kc++)
						{
							double dValue = dactivate(dPaddingImage.imageData[ch][r + kr][c + kc], 2);
							currentValue += K180[k].weight[ch][kr][kc] * dValue;
						}
					}
				}
				dImage.imageData[ch][ConvolutionX][ConvolutionY] = currentValue;
				ConvolutionY++;
			}
			ConvolutionX++;
		}
	}
	return true;
}
bool CNNCalc::BackLayer::dConvolutionW(image inPa, image outZ, kernal*& dkernal, int Kn)
{
	if (inPa.channel != kernalChannel)
	{
		return false;
	}
	image dPaddingImage;
	if (stride > 1)
	{
		innerPadding(outZ, dPaddingImage,stride-1,stride-1);
	}
	else
	{
		dPaddingImage = outZ;
	}
	dkernal = new kernal[neuroNumers];
	for (int k = 0; k < neuroNumers; k++) 
	{
		dkernal[k].row = kernalRow;
		dkernal[k].col = kernalCol;
		dkernal[k].channel = kernalChannel;
		dkernal[k].initKernal(1);
	}

	int WX = 0;
	int WY = 0;

	for (int k = 0; k < Kn; k++)
	{
		for (int ch = 0; ch < inPa.channel; ch++)
		{
			for (int r = 0; r < inPa.rows; r++)
			{
				for (int c = 0; c < inPa.cols; c++)
				{
					for (int i = 0; i < dPaddingImage.rows; i++)
					{
						for (int j = 0; j < dPaddingImage.cols; j++)
						{
							dkernal[k].weight[ch][WX][WY] += inPa.imageData[ch][r][c]*dPaddingImage.imageData[k][r + i][c + j];
						}
					}
					WY++;
				}
				WX++;
			}
			
		}
	}

	return true;
}
void CNNCalc::BackLayer::dPadding(image BeforePaddingZ, image& AfterPaddingZ, int padSizeR, int padSizeC)
{
	AfterPaddingZ.rows = BeforePaddingZ.rows + 2 * padSizeR;
	AfterPaddingZ.cols = BeforePaddingZ.cols + 2 * padSizeC;
	AfterPaddingZ.channel = BeforePaddingZ.channel;
	for (int ch = 0; ch < AfterPaddingZ.channel; ch++)
	{
		for (int r = 0; r < AfterPaddingZ.rows; r++)
		{
			for (int c = 0; c < AfterPaddingZ.cols; c++)
			{
				int rindex = 0;
				int cindex = 0;
				if (r < padSizeR)
				{
					rindex = 0;
				}
				else if (r> BeforePaddingZ.rows + padSizeR - 1)
				{
					rindex = BeforePaddingZ.rows - 1;
				}
				else
				{
					rindex = r-padSizeR;
				}
				if (c < padSizeC)
				{
					cindex = 0;
				}
				else if (c> BeforePaddingZ.cols + padSizeC - 1)
				{
					cindex = BeforePaddingZ.cols - 1;
				}
				else
				{
					cindex =c-padSizeC;
				}
				AfterPaddingZ.imageData[ch][r][c] = BeforePaddingZ.imageData[ch][rindex][cindex];	

			}
		}
	}
}
double CNNCalc::BackLayer::dactivate(double a, int fun)
{
	if (fun == 2)
	{//Relu
		if (a < 0)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		if (a < 0)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
}
bool CNNCalc::BackLayer::dPooling(image actImage, image outImage, image& dPoolingImage)
{
	dPoolingImage.channel = actImage.channel;
	dPoolingImage.rows = actImage.rows;
	dPoolingImage.cols = actImage.cols;
	dPoolingImage.initImage();
	int outIndexRow = 0;
	int outIndexCol = 0;
	for (int ch = 0; ch < actImage.channel; ch++)
	{
		for (int r = 0; r < actImage.rows; r += poolingStride)
		{
			for (int c = 0; c < actImage.cols; c += poolingStride)
			{
				double currentMaxValue = 0;
				int maxXValueIndex = 0;
				int maxYValueIndex = 0;
				for (int i = 0; i < poolingStride; i++)
				{
					for (int j = 0; j < poolingStride; j++)
					{
						if (actImage.imageData[ch][r + i][c + j]>currentMaxValue)
						{
							currentMaxValue = actImage.imageData[ch][r + i][c + j];
							maxXValueIndex = i;
							maxYValueIndex = j;
						}
					}
				}
				dPoolingImage.imageData[ch][r + maxXValueIndex][c + maxYValueIndex] += outImage.imageData[ch][outIndexRow][outIndexCol];
				outIndexCol++;
			}
			outIndexRow++;
		}
	}
	return true;
}
void CNNCalc::BackLayer::innerPadding(image beforePaddingZ, image& AfterPaddingZ,int innerSizeRow,int innerSizeCol)
{
	innerSizeRow = innerSizeRow < 0 ? 0 : innerSizeRow;
	innerSizeCol = innerSizeCol < 0 ? 0 : innerSizeCol;
	AfterPaddingZ.channel = beforePaddingZ.channel;
	AfterPaddingZ.rows = beforePaddingZ.rows*(1 + innerSizeRow);
	AfterPaddingZ.cols = beforePaddingZ.cols*(1 + innerSizeCol);
	AfterPaddingZ.initImage();
	for (int ch = 0; ch < beforePaddingZ.channel; ch++)
	{
		for (int r = 0; r < AfterPaddingZ.rows; r += innerSizeRow)
		{
			for (int c = 0; c < AfterPaddingZ.cols; c += innerSizeCol)
			{
				AfterPaddingZ.imageData[ch][r][c] = beforePaddingZ.imageData[ch][r][c];
				for (int i = 1; i <= innerSizeRow; i++)
				{
					for (int j = 1; j <= innerSizeCol; j++)
					{
						AfterPaddingZ.imageData[ch][r + i][c + j] = 0;
					}
				}
			}
		}
	}
}
kernal* CNNCalc::BackLayer::TMatrixKernal(const kernal* kernalSeris, int neuroNums)
{
	kernal* retKernal180 = new kernal[neuroNums];
	for (int i = 0; i < neuroNums; i++)
	{
		retKernal180[i].channel = kernalSeris[i].channel;
		retKernal180[i].col = kernalSeris[i].row;
		retKernal180[i].row = kernalSeris[i].col;
		retKernal180[i].initKernal(1);
		for (int ch = 0; ch < retKernal180[i].channel; ch++)
		{
			for (int r = 0; r < retKernal180[i].row; r++)
			{
				for (int c = 0; c < retKernal180[i].col; c++)
				{
					retKernal180[i].weight[ch][r][c] = kernalSeris[i].weight[ch][c][r];
				}
			}
		}
	}
	return retKernal180;
}