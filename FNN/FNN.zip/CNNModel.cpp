#include"CNNModel.h"

CNNModel::CNNModel()
{
	C = 0;
	maxIteration = 1000;
	minLoss = 0.01;
	learnRate = 0.01;
	diffLoss = 0.001;
	lossType = 1;
	batchSize = 1;
}
bool CNNModel::LaunchCNNModel(image image0, double* outValues, int outLentgh)
{
	bool ret = true;
	image tempIamge = image0;
	for (CNNCalc layer : CNNLayerSeries)
	{
		layer.SetInput(tempIamge);
		if(layer.LaunchConvolution())
		{
			tempIamge = layer.getOutImage();
		}
		else
		{
			ret = false;
			break;
		}

	}
	ret &= outValues != NULL;
	if (ret)
	{
		for (int ch = 0; ch < tempIamge.channel; ch++)
		{
			outValues[ch] = tempIamge.imageData[ch][0][0];
		}
	}
	return ret;
}
void CNNModel::addCNNLayer(CNNCalc aLayer)
{
	CNNLayerSeries.push_back(aLayer); 
}
void CNNModel::popLayer()
{
	CNNLayerSeries.pop_back();
}
void CNNModel::clearModel()
{
	CNNLayerSeries.clear();
}
int CNNModel::getLastLayerOutChannel()
{
	if (CNNLayerSeries.size() > 0)
	{
		return CNNLayerSeries.back().GetOutLength();
	}
	else
	{
		return 0;
	}
}
void CNNModel::getLastLayerOutSize(int& dim1, int& dim2)
{
	if (CNNLayerSeries.size() > 0)
	{
		dim1 = CNNLayerSeries.back().getOutImage().rows;
		dim2 = CNNLayerSeries.back().getOutImage().cols;
	}
	else
	{
		dim1 = 0;
		dim2 = 0;
	}
}
layerType CNNModel::getLastLayerType()
{
	if (CNNLayerSeries.size() > 0)
	{
		return CNNLayerSeries.back().getCurrentLayerType();
	}
	else
	{
		return CONVOLUTION;
	}
}
CNNCalc CNNModel::getLayer(int layerIndex)
{
	if (layerIndex >= 0 & layerIndex < CNNLayerSeries.size())
	{
		return CNNLayerSeries.at(layerIndex);
	}
	else
	{
		CNNCalc aNewLayer;
		aNewLayer.setHiddenNum(-1);
		return aNewLayer;
	}
}
void CNNModel::addInputImage(image im, double* theOutput, int outLenth)
{//chack size of img BY comparring to the first
	if (InputImageSeries.size() > 0 & outLen == outLenth)
	{
		image lastImage = InputImageSeries.back();
		bool colEqual = lastImage.cols == im.cols;
		bool channelEqual = lastImage.channel == im.channel;
		bool rowEqual = lastImage.channel == im.channel;
		if (colEqual & channelEqual & rowEqual)
		{
			InputImageSeries.push_back(im);
			IdealOutput.push_back(theOutput);
			outLen = outLenth;
		}
	}
	else
	{
		InputImageSeries.push_back(im);
		IdealOutput.push_back(theOutput);
	}

}
bool CNNModel::startTrainning()
{
	bool ret = true;
	if (InputImageSeries.size() == 0 | IdealOutput.size()==0 | outLen==0)
	{
		std::cout << "no image is input~" << std::endl;
		ret = false;
	}
	if (InputImageSeries.size() != IdealOutput.size())
	{
		std::cout << "size of input images is not equal to that of output" << std::endl;
		ret = false;
	}
	//size of each img has been check when added
	if (CNNLayerSeries.back().GetOutLength() != outLen | CNNLayerSeries.back().getCurrentLayerType() != FULLYCONNECTION)
	{
		std::cout << "cnn model is not bulit properly!" << std::endl;
		ret = false;
	}
	int NIMG = InputImageSeries.size();

	if (ret = true)
	{	
		int iterK = 0;
		double C = 0.0, lastC = 0.0;
		while (iterK<maxIteration)
		{
			int dpth = CNNLayerSeries.size();
			image* DeltaImageLayerSeries = new image[dpth+1];
			for (int im = 0; im < NIMG; im+=batchSize)
			{
				for (int b = 0; b < batchSize; b++)
				{
					image currentIMG = InputImageSeries.at(im+b);
					double* outValue = new double[outLen];
					memset(outValue, 0.0, outLen);
					ret = LaunchCNNModel(currentIMG, outValue, outLen);			
					C += calculateC(outValue, IdealOutput.at(im), outLen);
					if (ret == true)
					{
						
						double* dyVdx = new double[outLen];
						dcalculateC(outValue, IdealOutput.at(im), dyVdx, outLen);
						DeltaImageLayerSeries[dpth] = VectorToImg(dyVdx, outLen);
						CNNLayerSeries.back().setOutLossss(DeltaImageLayerSeries[dpth + 1]);
						for (int ly = dpth; ly >= 1; ly--)
						{
							CNNCalc layer = CNNLayerSeries.at(ly - 1);
							image DeltaImage;
							ret = layer.UpdateLayerLoss(DeltaImage);
							if (ret & ly != 1)
							{
								DeltaImageLayerSeries[ly-1] += DeltaImage;
								CNNLayerSeries.at(ly - 2).setOutLossss(DeltaImage);
							}
							else
							{
								break;
							}
						}
					}
					else
					{
						break;
					}
				}
				if (ret == true)
				{
					for (int ly = CNNLayerSeries.size(); ly >= 1; ly--)
					{
						CNNCalc layer = CNNLayerSeries.at(ly - 1);
						CNNLayerSeries.at(ly - 2).setOutLossss(DeltaImageLayerSeries[ly]);
						for (int b = 0; b < batchSize; b++)
						{
							image currentIMG = InputImageSeries.at(im + b);
							double* outValue = new double[outLen];
							memset(outValue, 0.0, outLen);
							ret = LaunchCNNModel(currentIMG, outValue, outLen);
							layer.UpdateLayerWB(batchSize);
						}
					}
					
				}
				else
				{
					break;
				}

			}
			if (C < minLoss | std::abs(C - lastC) < diffLoss)
			{
				break;
			}
			else
			{
				lastC = C;
			}
			iterK++;
			printf("iter: %d,C:%f", iterK,C);
		}		
	}
	return ret;
}
image CNNModel::VectorToImg(double *vec, int sz)
{
	image retImage;
	retImage.cols = 1;
	retImage.rows = 1;
	retImage.channel = sz;
	retImage.initImage();
	for (int ch = 0; ch < sz; ch++)
	{
		retImage.imageData[ch][0][0] = vec[ch];
	}
	return retImage;
}
bool CNNModel::launchBackwardPropagation(double C)
{
	return true;

}
double CNNModel::calculateC(double* y, double*x, int sz)
{//a:label b:out

	double sum = 0.0;
	for (int i = 0; i < sz; i++)
	{
		if (lossType == 1)
		{//square
			sum += 0.5*(y[i] - x[i])*(y[i] - x[i]);
		}
		else
		{//cross entropy
			sum += -(y[i]*std::log(x[i])+(1-y[i])*std::log(1-x[i]));
		}
	}
	return sum / sz;
}
void CNNModel::dcalculateC(double* x, double*y,double*dyVdx, int sz)
{

	for (int i = 0; i < sz; i++)
	{
		if (lossType == 1)
		{//square
			dyVdx [i]= y[i] - x[i];
		}
		else
		{//cross entropy
			dyVdx[i] = -(y[i] / x[i] - (1 - y[i]) / (1 - x[i]));
		}
	}
	
}