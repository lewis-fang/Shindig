#pragma once
#include<iostream>
#include<vector>

typedef struct image
{
	int rows;
	int cols;
	int channel;
	double ***imageData;
	image() :
		rows(0),
		cols(0),
		channel(0),
		imageData(NULL)
	{}
	bool initImage()
	{
		if (rows > 0 & cols > 0 & channel > 0)
		{
			srand((int)&rows);
			imageData = new double**[channel];
			for (int ch = 0; ch < channel; ch++)
			{
				imageData[ch] = new double*[rows];
				for (int r = 0; r < rows; r++)
				{
					imageData[ch][r] = new double[cols];
				}
			}
			for (int ch = 0; ch < channel; ch++)
			{
				for (int r = 0; r < rows; r++)
				{
					for (int c = 0; c < rows; c++)
					{
						imageData[ch][r][c] = 1.0*rand() / RAND_MAX;
					}
				}
			}
			return true;
		}
		else
		{
			return false;
		}
	}
	void freeImage()
	{
		if (imageData != NULL)
		{
			for (int ch = 0; ch < channel; ch++)
			{
				if (imageData[ch] != NULL)
				{
					for (int r = 0; r < rows; r++)
					{
						if (imageData[ch][r] != NULL)
						{
							delete imageData[ch][r];
							imageData[ch][r] = NULL;
						}
					}
					delete[] imageData[ch];
					imageData[ch] = NULL;
				}
			}
			delete[] imageData;
			imageData = NULL;
		}
		
		channel = 0;
		cols = 0;
		rows = 0;
	}
	image& operator+=(const image& im)
	{
		if (channel == im.channel & rows == im.rows & cols == im.cols)
		{
			for (int ch = 0; ch < channel; ch++)
			{
				for (int r = 0; r < rows; r++)
				{
					for (int c = 0; c < cols; c++)
					{
						imageData[ch][r][c] += im.imageData[ch][r][c];
					}
				}
			}
		}
		return *this;
	}
}image;
typedef struct kernal
{
	int row;
	int col;
	int channel;
	double*** weight;
	double** SeriesWeights;
	kernal():
		row(0),
		col(0),
		channel(0)
	{}
	void initKernal(double sd)
	{
		weight = new double**[channel];
		SeriesWeights = new double*[channel];
		for (int j = 0; j < channel; j++)
		{
			weight[j] = new double*[row];
			SeriesWeights = new double*[row*col];
			for (int i = 0; i < row; i++)
			{
				weight[j][i] = new double[col];
			}
		}	
		srand((int)&row);
		for (int ch = 0; ch < channel; ch++)
		{
			for (int r = 0; r < row; r++)
			{
				for(int c = 0; c < col;c++)
				{
					weight[ch][r][c] = sd * 1.0 * rand() / RAND_MAX / row / col / channel;
				}
			}
		}
	}
	void FreeWts()
	{
		if (weight != NULL)
		{
			for (int ch = 0; ch < channel; ch++)
			{
				if (weight[ch] != NULL)
				{
					for (int r = 0; r < row; r++)
					{
						if (weight[ch][r] != NULL)
						{
							delete weight[ch][r];
							weight[ch][r] = NULL;
						}
					}
					delete[] weight[ch];
					weight[ch] = NULL;
				}
			}
		}
		delete[] weight;
		weight = NULL;
		row = 0;
		col = 0;
		channel = 0;
	}
	kernal copy()
	{
		kernal tempK;
		tempK.channel = this->channel;
		tempK.col = this->col;
		tempK.row = this->row;
		tempK.initKernal(0);
		for (int ch = 0; ch < this->channel; ch++)
		{
			for (int r = 0; r < this->row; r++)
			{
				for (int c = 0; c < this->col; c++)
				{
					tempK.weight[ch][r][c] = this->weight[ch][r][c];
				}
			}
		}
		return tempK;
	}
	kernal& operator+=(const kernal& k1) 
	{
		if (channel == k1.channel & row == k1.row & col == k1.col)
		{
			for (int ch = 0; ch < channel; ch++)
			{
				for (int r = 0; r < row; r++)
				{
					for (int c = 0; c < col; c++)
					{
						weight[ch][r][c] += k1.weight[ch][r][c];
					}
				}
			}
		}
		return *this;
	}
	void apply(double ra)
	{

		for (int ch = 0; ch < channel; ch++)
		{
			for (int r = 0; r < row; r++)
			{
				for (int c = 0; c < col; c++)
				{
					weight[ch][r][c] *= ra;
				}
			}
		}
		
	}
}kernal;
typedef enum 
{
	SMALLER=0,
	SAME,
	BIGGER

}PaddingMethod;
typedef enum
{
	INPUT = 0,
	CONVOLUTION,
	FULLYCONNECTION,
	OUTPUT

}layerType;
class CNNCalc
{
public:
	CNNCalc();
	~CNNCalc(){};
	//init current Layer
	void initLayerMemory(int inRows, int inCols, int inChannel);
	void initKernals(int wtsRow, int wtsCol, int wtsChannel, int ns,int strd);
	void SetInput(image imago);//must set
	bool SetKernals(std::vector<kernal> kernals, int kernalrow, int kernalcol, int padsz, int strd, int ns);// must set
	void SetPoolings(int pldim1, int pldim2, int plStrd, int plFun);//can be set
	void SetActivateFun(int Act);//can be set
	void setlayerType(layerType lt){ thisLayerType = lt; }
	void setPaddingMethod(PaddingMethod pm){ padMoethod = pm; }
	void setHiddenNum(int hn){ HideLayerNumth = hn; }
	bool setOutLossss(image umg);

	void UpdateLayerWB(int bs);
	bool UpdateLayerLoss(image& retImage);
	bool LaunchConvolution();

	int GetOutLength(){ return neuroNums; }//outlen is same to number of neuros
	int getHiddenNum(){ return HideLayerNumth; }
	layerType getCurrentLayerType(){ return thisLayerType; }
	kernal getKernalNum(){ return CNNKernals[0]; };
	
	const image getOutImage();
	const image getActImage(){ return actImage; }
	const image getInputImage(){ return inputImage; }
	const image getPaddingImage(){ return padImage; }
private:
	int HideLayerNumth;
	image inputImage;
	int paddingrow;
	int paddingcol;
	image padImage;

	int stride;
	int neuroNums;//out channel
	int kernalRows;
	int kernalCols;
	int kernalChannel; //kernal
	
	kernal* CNNKernals;
	image actImage;//buffers before  pooling

	int poolingRow;
	int poolingCol;
	int poolingStride;
	int activateType;
	int poolingFun;    //pooling	

	image outImage;


	PaddingMethod padMoethod;
	layerType thisLayerType;

	bool isSetData;
	bool isSetConfig;
	bool isBufferInitiated;
	//calculate order
	void ReOrder();  //1st
	void padding();   //2nd
	void Convolution();  //3rd
	double activate(double a, int fun);
	void pooling();   //4th
	void setOutBuffer();//prior to the convolution step
	void setOutBuffer2();
class BackLayer
	{
	public:
		BackLayer(){ learnRate = 0.01; };
		~BackLayer(){};
		void setPaddingImage(image padimg){ paddingImage = padimg; }
		void setactImage(image actimg){ actImage = actimg; }
		void setIdealOut(image img){ dIdealOutVSdO = img; }

		kernal* shadowKernals;
	public:
			int lossType;//0:1/2*||y-x||,,1: cross Entropy
			image dIdealOutVSdO;
			kernal* CNNKernalsRotate180;
			image zBeforeAct;
			double learnRate;
			double* Loss;
			
			int neuroNumers;
			int kernalChannel;
			int kernalRow;
			int kernalCol;
			int stride;

			image inputImage;
			image paddingImage;
			image actImage;//outZ
			image PoolingImage;

			int poolingDim1;
			int poolingDim2;
			int poolingStride;

			void initDKernals();
			bool dConvolutionX(image inPa,image outZ, kernal* K180,int Kn,image& dImage);
			bool dConvolutionW(image inPa, image outZ, kernal*& dkernal, int Kn);
			bool dPooling(image actImage,image outImage, image &dPoolingImage);
			void dPadding(image BeforePaddingZ, image& AfterPaddingZ, int padSizeR, int padSizeC);
			double dactivate(double a, int fun);
			kernal* TMatrixKernal(const kernal* kernalSeris, int neuroNums);
			void innerPadding(image beforePaddingZ, image& AfterPaddingZ ,int innerSizeRow, int innerSizeCol);
	}BL;
};

/*
Forward:                           :   class CNNCalc;
	convolution layer:
		1:input->padding
		2:padding->convolution
		3:convolution->activation
		4:activation->pooling (3&4 are combined into one step)
		5:pooling->output
	fullyconnection layer:
		1:input->padding
		2:padding->convolution
		3:convolution->activation	
Backward:                          :   class CNNCalc::BackLayer;
	d convolution layer:
		1: C -> P(L+1) : Delta(L+1)
		2: P(L+1) -> A(L)
		3: A(L) -> Z : dactivate         :   double dactivate(...);
		4: Z -> A(L)   : W(Rot180) Conv Z  :   bool dConvolutionX(...);   step 2 is included
		5: Z -> W(L)   : Z Conv A(L)       :   bool dConvolutionW(...);   step 2 is included
		C->W(L)=C->P(L+1) * P(L+1)->W(L)
				=C->P(L+1) * P(L+1)->A(L) * A(L)->W(L)
				=C->P(L+1) * P(L+1)->A(L) * A(L)->Z * Z->W(L)
				=1 * 2 * 3 * 5
				=Delta(L+1) * 2(L) * 3(L) * 5(L)
		Delta(L+1)=C->P(L+1)
					=C->P(L+2) * P(L+2)->P(L+1) 
					=C->A(L+2) * P(L+2)->A(L+1) * A(L)->P(L+1)
					=C->A(L+2) * P(L+2)->A(L+1) * A(L)->Z * Z->P(L+1)
					=Delta(L+2) * 2(L+1) * 3(L+1) * 4(L+1)
	d fullyconnection layer:
		1: C -> A(L+1) : Delta(L+1)
		2: 
		3: A(L+1) -> Z : dactivate         :   double dactivate(...);
		4: Z -> A(L)   : W(Rot180) Conv Z  :   bool dConvolutionX(...);   step 2 is included
		5: Z -> W(L)   : Z Conv A(L)       :   bool dConvolutionW(...);   step 2 is included
		C->W(L)=C->A(L+1) * A(L+1)->W(L)
				=C->A(L+1) * A(L+1)->Z * Z->W(L)
				=1 * 2 * 4
				=Delta(L+1) * 2(L) * 4(L)
				Delta(L+1)=C->A(L+1)
				=C->A(L+2) * A(L+2)->A(L+1)
				=C->A(L+2) * A(L+2)->Z * Z->A(L+1)
				=Delta(L+2) * 3(L+1) * 5(L+1)
		Delta(L+1)=C->A(L+1)
				=C->A(L+2) * A(L+2)->A(L+1)
				=C->A(L+2) * P(L+2)->Z * Z->A(L+1)
				=Delta(L+2) * 3(L+1) * 4(L+1)
*/

