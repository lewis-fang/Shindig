#pragma once

#include"CNNLayer.h"
#include<vector>

class CNNModel
{
public:
	CNNModel();
	~CNNModel(){};

	bool LaunchCNNModel(image image0, double* outValues, int outLentgh);
	void addCNNLayer(CNNCalc aLayer);
	void setMaxiter(int ite){ maxIteration = ite; }

	void popLayer();
	void clearModel();


	int getLastLayerOutChannel();
	int getLastLayerNum(){ return CNNLayerSeries.size(); }
	void getLastLayerOutSize(int& dim1, int& dim2);
	CNNCalc getLayer(int layerIndex);
	layerType getLastLayerType();
	void softMax(double& x1, double& x2){};

	///////////////////training: backward propagation
	void addInputImage(image im, double* theOutput, int outLenth);
	bool startTrainning();
private:
	std::vector<CNNCalc> CNNLayerSeries;


	/////////////////trainig
	
	std::vector<image> InputImageSeries;
	std::vector<double*> IdealOutput;
	int outLen;
	int batchSize;
	double C;	
	int lossType;
	inline double calculateC(double* y, double*x, int sz);
	inline void dcalculateC(double* y, double*x, double* dyVdx, int sz);
	bool launchBackwardPropagation(double C);
	int maxIteration;
	double minLoss;
	double diffLoss;
	double learnRate;
	kernal* dw;

	///////////fundenmental functions
	image VectorToImg(double *vec, int sz);
};