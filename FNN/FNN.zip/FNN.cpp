#include "FNN.h"
#include <iostream>
FNN::FNN(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	//ui.spinBox_rows->setValue(16);
	//ui.spinBox_cols->setValue(33);
	connect(ui.pushButton_importImage, SIGNAL(clicked()), this, SLOT(ImpotsDatas()), Qt::AutoConnection);
	connect(ui.pushButton_ImportWts, SIGNAL(clicked()), this, SLOT(ImpotWts()), Qt::AutoConnection);
	connect(ui.comboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(ChangeTrainMode(int)), Qt::AutoConnection);
	connect(ui.pushButton_LaunchCNNLayer, SIGNAL(clicked()), this, SLOT(Launch()), Qt::AutoConnection);
	connect(ui.pushButton_ViewAct, SIGNAL(clicked()), this, SLOT(ViewAct()), Qt::AutoConnection);
	connect(ui.pushButton_ViewOut, SIGNAL(clicked()), this, SLOT(ViewOut()), Qt::AutoConnection);
	connect(ui.pushButton_addLayer, SIGNAL(clicked()), this, SLOT(AddLayer()), Qt::AutoConnection);
	connect(ui.pushButton_LaunchModel, SIGNAL(clicked()), this, SLOT(LauchCNNModel()), Qt::AutoConnection);
	connect(ui.comboBox_LayerType, SIGNAL(currentIndexChanged(int)), this, SLOT(uiSetFCPara(int)), Qt::AutoConnection);
	connect(ui.pushButton_popBackLayer, SIGNAL(clicked()), this, SLOT(popBack()), Qt::AutoConnection);
	connect(ui.pushButton_TraainingMode, SIGNAL(clicked()), this, SLOT(LaunchTraing()),Qt::AutoConnection);
	connect(ui.pushButton_ImportIdealOut,SIGNAL(clicked()), this, SLOT(ImportIdlO()), Qt::AutoConnection);
	QString open_file = "C:/Users/63473/Pictures/Saved Pictures/1.jpg";
	QImage image;
	image.load(open_file);
	ui.label->setPixmap(QPixmap::fromImage(image).scaled(ui.label->size()));
	std::cout << image.height() << std::endl;
	std::cout <<image.width() << std::endl;
	std::cout << image.depth() << std::endl;
	isDataImported = false;

	treeViewModel = new QStandardItemModel;
	ui.treeView->setModel(treeViewModel);
	QStringList header;
	header << "Layer" << "Dim1"<<"Dim2"<<"Dim3";
	treeViewModel->setHorizontalHeaderLabels(header);
	ui.treeView->setColumnWidth(0, 400);
	ui.treeView->setColumnWidth(1, 100);
	ui.treeView->setColumnWidth(2, 100);
	ui.treeView->setColumnWidth(3, 100);
}
void FNN::ChangeTrainMode(int mode)
{
	if (mode == 0)
	{
		ui.label_Traingmode->setText("Train Mode");
		ui.pushButton_TraainingMode->setText("----->");
	}
	else
	{
		ui.label_Traingmode->setText("Step Mode");
		ui.pushButton_TraainingMode->setText(">>>>>>>>>");
	}
}
void FNN::ImportIdlO()
{
	FreeDts();
	for (int i = 0; i < IdealOut.size(); i++)
	{
		delete IdealOut.at(i);
	}
	IdealOut.clear();
	int imgNum = ui.spinBox_numberimg->value();
	int outlen = ui.spinB_ExpectedOutLen->value();
	for (int im = 0; im < imgNum; im++)
	{
		double* IdealOutCevtor=new double[outlen];
		memset(IdealOutCevtor, 0, outlen);
		IdealOut.push_back(IdealOutCevtor);
	}


	QString fileName = QFileDialog::getOpenFileName(this, tr("import IdealOut"), "", tr("CSV(*.csv)","TXT(*,txt)")); //ѡ��·��
	//std::cout << fileName.toLocal8Bit().data() << std::endl;
	QFile IDO(fileName);
	int cnRows = -1;
	bool GoodCol = true;
	int imIndex = 0;
	if (IDO.open(QIODevice::ReadOnly | QIODevice::Text))
	{
		QString qLine;
		QTextStream qstream(&IDO);

		while (!qstream.atEnd() & (++cnRows)<imgNum)
		{
			qLine = qstream.readLine();
			QStringList listLine = qLine.split(',');
			if (listLine.size() == outlen)
			{
				double* o = IdealOut[cnRows];
				for (int i = 0; i < outlen; i++)
				{
					o[i] = listLine.at(i).toDouble();
				}
			}
			else
			{
				std::cout << "A bad line is read~" << std::endl;
				GoodCol = false;
				isOutReady = false;
				break;
			}
		}
	}
	if (cnRows == imgNum)
	{
		isOutReady = true;
		for (int r = 0; r < rows; r++)
		{
			QString aLne;
			for (int c = 0; c < cols; c++)
			{
				aLne += QString::number(ImportImages.at(0).imageData[0][r][c]) + ',';

			}
			ui.textBrowser->append(aLne);
		}
		ui.lineEdit->setText("Yes");
		ui.textBrowser->append("Dts are read!");
		CNNLayer.SetInput(ImportImages.at(0));
		ui.textBrowser->append("Dts are Delivered to CNN Layer!");
		isDataImported = true;
	}
	else
	{
		ui.lineEdit->setText("No");
	}


}
void FNN::ImpotsDatas()
{
	FreeDts();
	int imgNum = ui.spinBox_numberimg->value();
	int rows = ui.spinBox_rows->value();
	int cols = ui.spinBox_cols->value();
	for (int im = 0; im < imgNum; im++)
	{
		image ImportImage;
		ImportImage.channel = ui.spinBox_chans->value();
		ImportImage.rows = rows;
		ImportImage.cols = cols;
		ImportImage.initImage();
		ImportImages.push_back(ImportImage);
	}


	QString fileName = QFileDialog::getOpenFileName(this, tr("import Dts"), "", tr("CSV(*.csv)")); //ѡ��·��
	std::cout << fileName.toLocal8Bit().data() << std::endl;
	QFile Dts(fileName);
	int cnRows = -1;
	bool GoodCol=true;
	int imIndex = 0;
	if (Dts.open(QIODevice::ReadOnly | QIODevice::Text))
	{
		QString qLine;
		QTextStream qstream(&Dts);
		qLine = qstream.readLine();
		
		while (!qstream.atEnd() & (++cnRows)<imgNum*rows)
		{
			qLine = qstream.readLine();
			QStringList listLine = qLine.split(',');
			if (listLine.size() == cols+1)
			{
				imIndex = std::ceil(cnRows / rows);
				int curtRow = cnRows - rows*imIndex;
				if (curtRow < rows)
				{

					for (int c = 0; c < cols; c++)
					{
						ImportImages.at(imIndex).imageData[0][curtRow][c] = listLine.at(c + 1).toDouble();
					}
				}				
			}
			else
			{
				std::cout << "A bad line is read~" << std::endl;
				GoodCol = false;
				break;
			}
		}
	}
	if (cnRows == imgNum*rows & GoodCol)
	{
		for (int r = 0; r < rows; r++)
		{
			QString aLne;
			for (int c = 0; c < cols; c++)
			{
				aLne += QString::number(ImportImages.at(0).imageData[0][r][c]) + ',';
				
			}
			ui.textBrowser->append(aLne);
		}
		ui.lineEdit->setText("Yes");
		ui.textBrowser->append("Dts are read!");
		CNNLayer.SetInput(ImportImages.at(0));
		ui.textBrowser->append("Dts are Delivered to CNN Layer!");
		isDataImported = true;
	}
	else
	{
		ui.lineEdit->setText("No");
	}

	
}
void FNN::SetInputSize()
{
}
void FNN::ImpotWts()
{
	FreeWts();
	int neuroNum = ui.spinBox_NeuroNums->value();
	QString fileName = QFileDialog::getOpenFileName(this, tr("import Dts"), "", tr("CSV(*.csv)")); //ѡ��·��
	std::cout << fileName.toLocal8Bit().data() << std::endl;
	QFile Wts(fileName);
	bool GoodLine = true;
	int row = ui.spinBox_WtsRows->value();
	int col = ui.spinBox_WtsCols->value();
	int padsize = 0;
	int strd = ui.spinBox_Strides->value();
	if (Wts.open(QIODevice::ReadOnly | QIODevice::Text))
	{
		QString qLine;
		QTextStream qstream(&Wts);
		while (!qstream.atEnd())
		{
			qLine = qstream.readLine();
			QStringList qstrlist = qLine.split(',');
			if (qstrlist.size() == row*col)
			{
				kernal tempKernal;
				tempKernal.channel = 1;
				tempKernal.row = row;
				tempKernal.col = col;
				tempKernal.initKernal(1);
				for (int r = 0; r < row; r++)
				{
					for (int c = 0; c < col; c++)
					{
						tempKernal.weight[0][r][c] = qstrlist.at(r* col + c).toDouble();
					}
				}
				kernalSeries.push_back(tempKernal);
			}
			else
			{
				std::cout << "a bad line is read~" << std::endl;
				GoodLine = false;
			}
		}
	}
	if (kernalSeries.size() == neuroNum & GoodLine == true)
	{
		for (int kn = 0; kn < neuroNum; kn++)
		{
			QString aLne;
			for (int r = 0; r < kernalSeries.at(kn).row; r++)
			{			
				for (int c = 0; c < kernalSeries.at(kn).col; c++)
				{
					aLne += QString::number(kernalSeries.at(kn).weight[0][r][c]) + ',';

				}
				
			}
			ui.textBrowser->append(aLne);
		}

		ui.lineEdit_WtsReady->setText("Yes");
		ui.textBrowser->append("Wts are read!");
		CNNLayer.SetKernals(kernalSeries, row, col, padsize, strd, neuroNum);
		ui.textBrowser->append("Wts are tranported to CNN Layer!");
	}
	else
	{
		std::cout << "read neros:" << kernalSeries.size() << std::endl;
		ui.lineEdit_WtsReady->setText("No");
	}
}
void FNN::FreeDts()
{
	for (int im = 0; im < ImportImages.size(); im++)
	{
		ImportImages.at(im).freeImage();
	}
	ImportImages.clear();

}
void FNN::FreeWts()
{
	int neurosNums = kernalSeries.size();
	for (int kn = 0; kn < neurosNums; kn++)
	{
		kernalSeries.at(kn).FreeWts();
	}
	kernalSeries.clear();
}
void FNN::Launch()
{
	if (CNNLayer.LaunchConvolution())
	{
		ui.spinBox_OutDims->setMaximum(CNNLayer.GetOutLength()-1);
		ui.spinBox_OutDims->setMinimum(0);
	}

}
void FNN::ViewOut()
{
	int currentDim = ui.spinBox_OutDims->value();
	const image outImage=CNNLayer.getOutImage();
	ui.textBrowser->append("OutImage Slice:" + QString::number(currentDim));
	for (int r = 0; r < outImage.rows; r++)
	{
		QString theLine;
		for (int c = 0; c < outImage.cols; c++)
		{
			theLine += QString::number(outImage.imageData[currentDim][r][c]) + ',';
		}
		ui.textBrowser->append(theLine);
	}
}
void FNN::ViewAct()
{
	int currentDim = ui.spinBox_OutDims->value();
	const image actImage = CNNLayer.getActImage();
	ui.textBrowser->append("ActImage Slice:" + QString::number(currentDim));
	for (int r = 0; r < actImage.rows; r++)
	{
		QString theLine;
		for (int c = 0; c < actImage.cols; c++)
		{
			theLine += QString::number(actImage.imageData[currentDim][r][c]) + ',';
		}
		ui.textBrowser->append(theLine);
	}
}
void FNN::AddLayer()
{
	bool checkPara = true;
	if (ui.comboBox_LayerType->currentIndex() == 0)
	{
		if (ui.spinBox_WtsRows->value() <= 1 | ui.spinBox_WtsCols->value()<=1)
		{
			checkPara = false;
			ui.textBrowser->append("kernal size must be larger than 1!");
		}
		if (MyCNNModel.getLastLayerType() == FULLYCONNECTION)
		{
			checkPara = false;
			ui.textBrowser->append("Convolution layer can not be put behind a FC!");
		}
	}

	if (checkPara)
	{
		int neuroNum = ui.spinBox_NeuroNums->value();
		int WtsRow = ui.spinBox_WtsRows->value();
		int WtsCol = ui.spinBox_WtsCols->value();
		int strd = ui.spinBox_Strides->value();
		int WtsChannel = MyCNNModel.getLastLayerOutChannel();
		if (WtsChannel == 0)
		{//first layer
			WtsChannel = ui.spinBox_chans->value();

		}
		std::vector<kernal> kernalSeries;
		for (int kn = 0; kn < neuroNum; kn++)
		{
			kernal tempKernal;
			tempKernal.channel = WtsChannel;
			tempKernal.row = WtsRow;
			tempKernal.col = WtsCol;
			tempKernal.initKernal(1);
			kernalSeries.push_back(tempKernal);
		}
		CNNCalc CurrentLayer;
		CurrentLayer.initKernals(WtsRow, WtsCol, WtsChannel, neuroNum, strd);
		CurrentLayer.setHiddenNum(MyCNNModel.getLastLayerNum());
		CurrentLayer.setlayerType((layerType)(ui.comboBox_LayerType->currentIndex() + 1));
		int lastRow = 0;
		int lastCol = 0;
		MyCNNModel.getLastLayerOutSize(lastRow, lastCol);
		if (lastRow == 0 | lastCol == 0)
		{
			lastRow = ui.spinBox_rows->value();
			lastCol = ui.spinBox_cols->value();
		}
		CurrentLayer.initLayerMemory(lastRow, lastCol, WtsChannel);//th
		MyCNNModel.addCNNLayer(CurrentLayer);	
	}
	if (checkPara)
	{
		int lastRow = 0;
		int lastCol = 0;
		MyCNNModel.getLastLayerOutSize(lastRow, lastCol);
		if (lastRow == 0 | lastCol == 0)
		{
			lastRow = ui.spinBox_rows->value();
			lastCol = ui.spinBox_cols->value();
		}
		ui.textBrowser->append("add layer successfully!");
		ui.lineEdit_depth->setText(QString::number(MyCNNModel.getLastLayerNum()));
		ui.lineEdit_outlen->setText(QString::number(MyCNNModel.getLastLayerOutChannel()));
		ui.lineEdit_outRow->setText(QString::number(lastRow));
		ui.lineEdit_outCol->setText(QString::number(lastCol));

		if (ui.comboBox_LayerType->currentIndex() == 1)
		{
			uiSetFCPara(1);
		}
		UpdateCNNTreeView();
	}


}
void FNN::LauchCNNModel()
{
	bool isModelReady = true;
	int expectedOutLen = ui.spinB_ExpectedOutLen->value();
	int outRow = 0;
	int outCol = 0;
	MyCNNModel.getLastLayerOutSize(outRow, outCol);
	if (MyCNNModel.getLastLayerOutChannel() != expectedOutLen)
	{
		ui.textBrowser->append("current output Lentgh is not equal to that of expectd!");
		isModelReady = false;
	}
	if (outRow != 1 | outCol != 1)
	{
		ui.textBrowser->append("the Model is not complete!");
		isModelReady = false;
	}
	if (isModelReady &  isDataImported)
	{
		double *outVector = new double[expectedOutLen];
		int indexImg = ui.spinBox_inputImageIndex->value();

		if (indexImg<ImportImages.size() & MyCNNModel.LaunchCNNModel(ImportImages.at(indexImg), outVector, expectedOutLen))
		{
			ui.textBrowser->append("CNN calc successfully!");
			for (int i = 0; i < expectedOutLen; i++)
			{
				ui.textBrowser->append(QString::number(outVector[i]));
			}
		}
		else
		{
			ui.textBrowser->append("CNN calc faily!");
		}
	}
	else
	{
		ui.textBrowser->append("Image is not imported Or Model is not constructed!");
	}
}
void FNN::uiSetFCPara(int fc)
{
	fc = ui.comboBox_LayerType->currentIndex();
	if (fc == 1)
	{
		int row = 0;
		int col = 0;
		MyCNNModel.getLastLayerOutSize(row, col);
		if (row == 0 | col == 0)
		{
			row = ui.spinBox_rows->value();
			col = ui.spinBox_cols->value();
		}
		ui.spinBox_WtsRows->setValue(row);
		ui.spinBox_WtsCols->setValue(col);

	}
}
void FNN::popBack()
{
	MyCNNModel.popLayer();
	int lastRow = 0;
	int lastCol = 0;
	MyCNNModel.getLastLayerOutSize(lastRow, lastCol);
	if (lastRow == 0 | lastCol == 0)
	{
		lastRow = ui.spinBox_rows->value();
		lastCol = ui.spinBox_cols->value();
	}
	ui.textBrowser->append("add layer successfully!");
	ui.lineEdit_depth->setText(QString::number(MyCNNModel.getLastLayerNum()));
	ui.lineEdit_outlen->setText(QString::number(MyCNNModel.getLastLayerOutChannel()));
	ui.lineEdit_outRow->setText(QString::number(lastRow));
	ui.lineEdit_outCol->setText(QString::number(lastCol));
	UpdateCNNTreeView();
}
void FNN::UpdateCNNTreeView()
{
	//treeViewModel->clear();
	int dpth = MyCNNModel.getLastLayerNum();
	if (dpth > treeViewModel->rowCount())
	{
		CNNCalc currentLayer = MyCNNModel.getLayer(dpth - 1);
		if (currentLayer.getHiddenNum() == dpth - 1)
		{
			QString strLayerType;
			if (currentLayer.getCurrentLayerType() == CONVOLUTION)
			{
				strLayerType = "CONVOLUTION";
			}
			else
			{
				strLayerType = "FULLY CONNECTION";
			}
			QStandardItem* newItemRow0 = new QStandardItem;
			newItemRow0->setText("Layer " + QString::number(dpth - 1)+": "+strLayerType);
			//input image
			QList<QStandardItem*> InputRow;
			QStandardItem* newItemRol10 = new QStandardItem;
			QStandardItem* newItemRol11 = new QStandardItem;
			QStandardItem* newItemRol12 = new QStandardItem;
			QStandardItem* newItemRol13 = new QStandardItem;

			newItemRol10->setText("Input Image");
			newItemRol11->setText(QString::number(currentLayer.getInputImage().rows));
			newItemRol12->setText(QString::number(currentLayer.getInputImage().cols));
			newItemRol13->setText(QString::number(currentLayer.getInputImage().channel));
			InputRow << newItemRol10 << newItemRol11 << newItemRol12 << newItemRol13;
			newItemRow0->appendRow(InputRow);


			//padding image
			QList<QStandardItem*> PaddingRow;
			QStandardItem* newItemRol20 = new QStandardItem;
			QStandardItem* newItemRol21 = new QStandardItem;
			QStandardItem* newItemRol22 = new QStandardItem;
			QStandardItem* newItemRol23 = new QStandardItem;
			newItemRol20->setText("Padding Image");
			newItemRol21->setText(QString::number(currentLayer.getPaddingImage().rows));
			newItemRol22->setText(QString::number(currentLayer.getPaddingImage().cols));
			newItemRol23->setText(QString::number(currentLayer.getPaddingImage().channel));
			PaddingRow << newItemRol20 << newItemRol21 << newItemRol22 << newItemRol23;
			newItemRow0->appendRow(PaddingRow);

			//WET image
			QList<QStandardItem*> KernalRow;
			QStandardItem* newItemRolK0 = new QStandardItem;
			QStandardItem* newItemRolK1 = new QStandardItem;
			QStandardItem* newItemRolK2 = new QStandardItem;
			QStandardItem* newItemRolK3 = new QStandardItem;
			newItemRolK0->setText("kernals x " + QString::number(currentLayer.GetOutLength()));
			newItemRolK1->setText(QString::number(currentLayer.getKernalNum().row));
			newItemRolK2->setText(QString::number(currentLayer.getKernalNum().col));
			newItemRolK3->setText(QString::number(currentLayer.getKernalNum().channel));
			KernalRow << newItemRolK0 << newItemRolK1 << newItemRolK2 << newItemRolK3;
			newItemRow0->appendRow(KernalRow);
			

			if (currentLayer.getCurrentLayerType() == CONVOLUTION)
			{//activation image
				QList<QStandardItem*> ActRow;
				QStandardItem* newItemRol30 = new QStandardItem;
				QStandardItem* newItemRol31 = new QStandardItem;
				QStandardItem* newItemRol32 = new QStandardItem;
				QStandardItem* newItemRol33 = new QStandardItem;
				newItemRol30->setText("Convolution & Activate Image");
				newItemRol31->setText(QString::number(currentLayer.getActImage().rows));
				newItemRol32->setText(QString::number(currentLayer.getActImage().cols));
				newItemRol33->setText(QString::number(currentLayer.getActImage().channel));
				ActRow << newItemRol30 << newItemRol31 << newItemRol32 << newItemRol33;
				newItemRow0->appendRow(ActRow);
			}
			//output image
			QList<QStandardItem*> outRow;
			QStandardItem* newItemRol40 = new QStandardItem;
			QStandardItem* newItemRol41 = new QStandardItem;
			QStandardItem* newItemRol42 = new QStandardItem;
			QStandardItem* newItemRol43 = new QStandardItem;
			newItemRol40->setText("Out Image");
			newItemRol41->setText(QString::number(currentLayer.getOutImage().rows));
			newItemRol42->setText(QString::number(currentLayer.getOutImage().cols));
			newItemRol43->setText(QString::number(currentLayer.getOutImage().channel));
			outRow << newItemRol40 << newItemRol41 << newItemRol42 << newItemRol43;
			newItemRow0->appendRow(outRow);

			treeViewModel->appendRow(newItemRow0);
		}
		else
		{
			ui.textBrowser->append("It's not the layer i need~");
		}
	}
	else
	{
		treeViewModel->removeRow(treeViewModel->rowCount() - 1);
	}
}
void FNN::LaunchTraing()
{

}