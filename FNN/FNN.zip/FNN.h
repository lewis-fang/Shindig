#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_FNN.h"
#include "qfiledialog.h"
#include "qtextstream.h"
#include "CNNLayer.h"
#include <vector>
#include"qstandarditemmodel.h"
#include "CNNModel.h"
//#include "winldap.h"

class FNN : public QMainWindow
{
	Q_OBJECT

public:
	FNN(QWidget *parent = Q_NULLPTR);

private:
	Ui::FNNClass ui;
	
	std::vector<image> ImportImages;
	std::vector<double*> IdealOut;
	std::vector<kernal> kernalSeries;
	CNNCalc CNNLayer;
	CNNModel MyCNNModel;
	bool isDataImported;
	QStandardItemModel* treeViewModel;

	void FreeDts();
	void UpdateCNNTreeView();
public slots:
	void ImpotsDatas();
	void ImpotWts();
	void SetInputSize();
	void FreeWts();
	void Launch();
	void ViewOut();
	void ViewAct();
	void AddLayer();
	void LauchCNNModel();
	void uiSetFCPara(int fc);
	void popBack();
	void ChangeTrainMode(int);
	void LaunchTraing();
	void ImportIdlO();
};
